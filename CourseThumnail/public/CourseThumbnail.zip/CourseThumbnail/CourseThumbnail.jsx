import React from "react";
export default function Python()
{
    return(
        <>
            <div style={{display:"flex",marginLeft:"450px", width:"540px",height:"380px", top:"200px", position:"relative"}}>
                
                <div style={{width:"430px",height:"230px", justifyContent:"center", textAlign:"center",paddingTop:"50px", position:"relative", border:"3px solid black", borderRadius:"10px"}}>
                    <img src="1.jpg" style={{width:"430px",height:"280px", top:"-50px", position:"relative"}} ></img>
                    
                    <div style={{backgroundColor:"gray", width:"75px",height:"20px", position:"absolute",right:"13px", top:"250px",}}><img src="Playlist.png" style={{width:"15px", height:"15px", marginLeft:"-60px",marginTop:"2px"}}
                    ></img><p style={{color:"white",marginTop:"-17px",marginLeft:"10px", fontSize:"13px" }}>33 Videos</p></div>
                    <h1 style={{position:"relative" ,top:"-45px", color:"darkblue"}}>Python For Beginners</h1>
                </div>
                    
            </div>
        </>
    )

}
